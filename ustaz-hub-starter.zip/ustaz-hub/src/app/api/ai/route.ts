import { NextResponse } from "next/server";
import { z } from "zod";
import { createClient } from "@/lib/supabase/server";
const schema=z.object({kind:z.string().min(1).max(40),grade:z.string().regex(/^[1-4]$/),subject:z.string().min(1).max(100),topic:z.string().min(1).max(300),objective:z.string().max(500).optional(),details:z.string().max(3000).optional()});
export async function POST(req:Request){
 const key=process.env.AI_API_KEY,base=(process.env.AI_API_BASE_URL||"https://api.openai.com/v1").replace(/\/$/,""),model=process.env.AI_MODEL||"gpt-4.1-mini";
 if(!key)return NextResponse.json({error:"ЖИ API кілті бапталмаған. .env.local ішіне AI_API_KEY қосып, серверді қайта іске қосыңыз."},{status:503});
 try{
  const body=schema.parse(await req.json());
  try{const db=await createClient();const {data:{user}}=await db.auth.getUser();if(!user)return NextResponse.json({error:"ЖИ құралын пайдалану үшін жүйеге кіріңіз."},{status:401});}catch{return NextResponse.json({error:"Авторизация қызметі бапталмаған."},{status:503});}
  const prompt=`Сен Қазақстанның бастауыш білім беру жүйесін білетін әдістемелік көмекшісің. Қазақ тілінде нақты, түсінікті жауап бер. Жас ерекшелігін ескер, оқу мақсатын ойдан ресми кодпен белгілеме. Құрал: ${body.kind}; сынып: ${body.grade}; пән: ${body.subject}; тақырып: ${body.topic}; оқу мақсаты: ${body.objective||"көрсетілмеген"}; қосымша талаптар: ${body.details||"жоқ"}. Нәтижені тақырыпшалармен және қолдануға ыңғайлы құрылыммен жаз.`;
  const r=await fetch(`${base}/chat/completions`,{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${key}`},body:JSON.stringify({model,messages:[{role:"system",content:"Сен мұғалімге арналған қауіпсіз әдістемелік көмекшісің."},{role:"user",content:prompt}],temperature:0.4}),cache:"no-store"});
  const data=await r.json();if(!r.ok)return NextResponse.json({error:data.error?.message||"AI провайдері сұранысты қабылдамады."},{status:502});
  const result=data.choices?.[0]?.message?.content;if(typeof result!=="string"||!result)return NextResponse.json({error:"ЖИ бос жауап қайтарды."},{status:502});
  return NextResponse.json({result});
 }catch(e){if(e instanceof z.ZodError)return NextResponse.json({error:"Формадағы мәліметтерді тексеріңіз."},{status:400});return NextResponse.json({error:"Сұранысты орындау кезінде қате орын алды."},{status:500});}
}