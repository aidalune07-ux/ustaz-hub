import Link from "next/link";
import { BookOpen, Gamepad2, Presentation, ClipboardCheck, BrainCircuit, FileQuestion, ArrowRight, Sparkles, UploadCloud, LibraryBig } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import type { Material } from "@/lib/types";
const categories = [
 { title:"Қысқа мерзімді жоспарлар",desc:"1–4-сыныпқа арналған ҚМЖ",href:"/materials?type=qmg",icon:BookOpen },
 { title:"Оқу ойындары",desc:"Сабаққа арналған интерактивті ойындар",href:"/games",icon:Gamepad2 },
 { title:"Презентациялар",desc:"Сабаққа дайын көрнекі материалдар",href:"/materials?type=presentation",icon:Presentation },
 { title:"БЖБ және ТЖБ",desc:"Бағалау тапсырмалары мен дескрипторлар",href:"/materials?type=bjb",icon:ClipboardCheck },
 { title:"ЖИ құралдары",desc:"Сабақ материалдарын дайындауға көмек",href:"/ai",icon:BrainCircuit },
 { title:"Тесттер",desc:"Білімді тексеруге арналған тапсырмалар",href:"/materials?type=test",icon:FileQuestion }
];
export default async function Home() {
 let latest: Material[] = []; let total = 0;
 try { const supabase = await createClient(); const {data,count} = await supabase.from("materials").select("id,title,description,type,subject,grade,topic,created_at,downloads,views,cover_url,file_path,file_name", {count:"exact"}).eq("visibility","public").eq("status","published").order("created_at",{ascending:false}).limit(3); latest = (data ?? []) as Material[]; total = count ?? 0; } catch {}
 return <main className="container" style={{paddingTop:28}}>
  <section className="hero"><span className="eyebrow"><Sparkles size={14}/> ҰСТАЗДАР ҚАУЫМДАСТЫҒЫ</span><h1>Сабағыңызға қажеттінің бәрі — бір кеңістікте.</h1><p>Бастауыш сынып мұғалімдеріне арналған ҚМЖ, ойындар, презентациялар, бағалау материалдары және пайдалы ЖИ құралдары.</p>
   <form action="/materials" className="search-box" style={{marginTop:25}}><input name="q" placeholder="Мысалы: 2-сынып математика, көбейту..." aria-label="Материал іздеу"/><button className="btn btn-primary" type="submit"><SearchIcon/> Материал табу</button></form>
   <div style={{display:"flex",gap:10,flexWrap:"wrap",marginTop:16}}><Link href="/upload" className="btn btn-soft"><UploadCloud size={16}/> Материал қосу</Link><Link href="/account" className="btn btn-secondary">Тіркелу / Кіру <ArrowRight size={16}/></Link></div>
  </section>
  <section className="section"><div className="section-head"><div><h2>Бөлімдерді таңдаңыз</h2><p className="muted" style={{margin:0}}>Керек материалға бірнеше қадамда өтіңіз.</p></div><Link href="/materials" className="nav-link">Барлық материалдар →</Link></div>
   <div className="grid-categories">{categories.map(c=>{const Icon=c.icon;return <Link href={c.href} className="category-card" key={c.title}><span className="category-icon"><Icon size={22}/></span><span><h3>{c.title}</h3><p>{c.desc}</p></span><ArrowRight size={16} style={{marginLeft:"auto",color:"#8ba0b8"}}/></Link>})}</div>
   <div className="stats"><div className="stat"><strong>{total.toLocaleString("kk-KZ")}</strong><span>Жарияланған материал</span></div><div className="stat"><strong>1–4</strong><span>Бастауыш сыныптар</span></div><div className="stat"><strong><LibraryBig size={24} style={{display:"inline",verticalAlign:"middle"}}/></strong><span>Ортақ білім кітапханасы</span></div></div>
  </section>
  <section className="section"><div className="section-head"><div><h2>Соңғы қосылған материалдар</h2><p className="muted" style={{margin:0}}>Қоғамдық кітапханаға соңғы жарияланғандары.</p></div><Link href="/materials" className="nav-link">Барлығын көру →</Link></div>
   {latest.length ? <div className="material-grid">{latest.map(m=><article className="material-card" key={m.id}><span className="material-type">{label(m.type)}</span><h3>{m.title}</h3><p>{m.description || "Материал сипаттамасы берілмеген."}</p><div className="meta"><span>{m.subject || "Пән көрсетілмеген"}</span><span>•</span><span>{m.grade ? `${m.grade}-сынып` : "Сынып көрсетілмеген"}</span></div><Link className="btn btn-secondary" href={`/materials/${m.id}`}>Материалды қарау <ArrowRight size={15}/></Link></article>)}</div> : <div className="panel"><p style={{margin:"0 0 8px",fontWeight:700}}>Әзірге жарияланған материал жоқ.</p><p className="muted" style={{margin:"0 0 16px",fontSize:14}}>Supabase бапталған соң мұғалімдер өз материалдарын қосып, осы жерде жариялай алады.</p><Link href="/upload" className="btn btn-primary">Алғашқы материалды қосу</Link></div>}
  </section>
  <section className="section" style={{paddingBottom:38}}><div className="panel" style={{display:"flex",alignItems:"center",justifyContent:"space-between",gap:24,flexWrap:"wrap",background:"linear-gradient(120deg,#fff,#f0f8ff)"}}><div><span className="eyebrow">МҰҒАЛІМГЕ КӨМЕКШІ</span><h2 style={{margin:"12px 0 6px"}}>Дайындық уақытын үнемдеңіз</h2><p className="muted" style={{margin:0,maxWidth:600}}>ЖИ құралдары арқылы сабақ мақсатын, тапсырмалар мен тест сұрақтарын дайындауға көмектесіңіз.</p></div><Link href="/ai" className="btn btn-primary">ЖИ құралдарын ашу <ArrowRight size={16}/></Link></div></section>
 </main>;
}
function SearchIcon(){return <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg>}
function label(t:string){return ({qmg:"ҚМЖ",game:"Ойын",presentation:"Презентация",bjb:"БЖБ",tjb:"ТЖБ",test:"Тест",other:"Материал"} as Record<string,string>)[t] || "Материал"}
