import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { MATERIAL_TYPES } from "@/lib/types";
export const dynamic="force-dynamic";
export default async function MaterialDetail({params}:{params:Promise<{id:string}>}) {
 const {id}=await params;
 try {
  const db=await createClient(); const {data,error}=await db.from("materials").select("*").eq("id",id).eq("visibility","public").eq("status","published").single();
  if(error||!data) notFound();
  const {data:link}=data.file_path?await db.storage.from("materials").createSignedUrl(data.file_path,60):{data:null};
  return <main className="container"><p style={{marginTop:28}}><Link className="nav-link" href="/materials">← Материалдар</Link></p><article className="panel" style={{marginTop:18}}><span className="material-type">{MATERIAL_TYPES.find(t=>t.value===data.type)?.label||"Материал"}</span><h1 className="page-title" style={{marginTop:16}}>{data.title}</h1><p className="muted">{data.subject||"Пән көрсетілмеген"} · {data.grade?`${data.grade}-сынып`:"Сынып көрсетілмеген"} · {data.author_name||"Автор"}</p><p style={{lineHeight:1.8}}>{data.description||"Сипаттама жоқ."}</p>{data.topic&&<p><b>Тақырып:</b> {data.topic}</p>}{link?.signedUrl?<a className="btn btn-primary" href={link.signedUrl} target="_blank" rel="noreferrer" download>{data.file_name||"Файлды ашу / жүктеу"}</a>:<p className="notice">Бұл материалға файл тіркелмеген.</p>}</article></main>
 } catch { return <main className="container"><div className="panel" style={{marginTop:32}}>Материалды ашу мүмкін болмады. Дерекқор баптауын тексеріңіз.</div></main> }
}