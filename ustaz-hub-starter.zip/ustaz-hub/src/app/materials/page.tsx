import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { MATERIAL_TYPES, SUBJECTS, type Material } from "@/lib/types";
export const dynamic = "force-dynamic";
type Props = { searchParams: Promise<{q?:string;type?:string;subject?:string;grade?:string;sort?:string}> };
export default async function MaterialsPage({searchParams}:Props) {
 const p=await searchParams; let items:Material[]=[]; let error="";
 try {
  const db=await createClient();
  let query=db.from("materials").select("id,title,description,type,subject,grade,topic,author_name,created_at,downloads,views,cover_url,file_path,file_name").eq("visibility","public").eq("status","published");
  if(p.q) query=query.or(`title.ilike.%${safe(p.q)}%,description.ilike.%${safe(p.q)}%,topic.ilike.%${safe(p.q)}%,keywords.cs.{${safe(p.q)}}`);
  if(p.type) query=query.eq("type",p.type);
  if(p.subject) query=query.eq("subject",p.subject);
  if(p.grade) query=query.eq("grade",Number(p.grade));
  query=query.order(p.sort==="popular"?"downloads":"created_at",{ascending:false}).limit(60);
  const r=await query; if(r.error) error=r.error.message; else items=(r.data??[]) as Material[];
 } catch { error="Дерекқор қосылмаған немесе баптау толық емес. .env.local және Supabase SQL файлын тексеріңіз."; }
 return <main className="container"><h1 className="page-title">Материалдар кітапханасы</h1><p className="muted">ҚМЖ, ойындар, презентациялар және бағалау материалдарын іздеңіз.</p>
 <form className="panel" action="/materials" style={{marginTop:22,marginBottom:22}}><div className="form-grid">
 <label className="field">Іздеу<input name="q" defaultValue={p.q} placeholder="Атауы, тақырыбы, кілт сөз..."/></label>
 <label className="field">Материал түрі<select name="type" defaultValue={p.type||""}><option value="">Барлық түрі</option>{MATERIAL_TYPES.map(t=><option value={t.value} key={t.value}>{t.label}</option>)}</select></label>
 <label className="field">Пән<select name="subject" defaultValue={p.subject||""}><option value="">Барлық пән</option>{SUBJECTS.map(s=><option key={s}>{s}</option>)}</select></label>
 <label className="field">Сынып<select name="grade" defaultValue={p.grade||""}><option value="">Барлық сынып</option>{[1,2,3,4].map(g=><option key={g} value={g}>{g}-сынып</option>)}</select></label>
 <label className="field">Сұрыптау<select name="sort" defaultValue={p.sort||"new"}><option value="new">Соңғы қосылғандар</option><option value="popular">Ең көп жүктелгендер</option></select></label>
 </div><div style={{display:"flex",gap:10,marginTop:18}}><button className="btn btn-primary" type="submit">Іздеу және сүзгілеу</button><Link className="btn btn-secondary" href="/materials">Тазарту</Link></div></form>
 {error&&<div className="notice" style={{marginBottom:16}}>Дереккөз туралы хабарлама: {error}</div>}
 {items.length?<div className="material-grid">{items.map(m=><article className="material-card" key={m.id}><span className="material-type">{MATERIAL_TYPES.find(t=>t.value===m.type)?.label||"Материал"}</span><h3>{m.title}</h3><p>{m.description||"Сипаттама жоқ."}</p><div className="meta"><span>{m.subject||"Пән көрсетілмеген"}</span><span>•</span><span>{m.grade?`${m.grade}-сынып`:"Сынып көрсетілмеген"}</span></div><div className="meta"><span>Қаралым: {m.views||0}</span><span>Жүктеу: {m.downloads||0}</span></div><Link className="btn btn-secondary" href={`/materials/${m.id}`}>Қарау</Link></article>)}</div>:<div className="panel"><h3 style={{marginTop:0}}>Сәйкес материал табылмады</h3><p className="muted">Іздеу сөзін өзгертіңіз немесе сүзгілерді алып тастаңыз. Жаңа материалды өзіңіз де қоса аласыз.</p><Link href="/upload" className="btn btn-primary">Материал қосу</Link></div>}
 </main>;
}
function safe(s:string){return s.replace(/[,%()]/g," ").trim()}
