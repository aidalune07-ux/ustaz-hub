 "use client";
import { useState, type FormEvent } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { MATERIAL_TYPES, SUBJECTS } from "@/lib/types";
const MAX_SIZE=25*1024*1024;
const ALLOWED=new Set(["pdf","doc","docx","ppt","pptx","xls","xlsx","jpg","jpeg","png","zip","html"]);
export default function UploadPage(){
 const [busy,setBusy]=useState(false),[message,setMessage]=useState(""),[progress,setProgress]=useState(0);
 async function submit(e:FormEvent<HTMLFormElement>){
  e.preventDefault();setMessage("");setBusy(true);setProgress(5);
  try{
   const db=createClient();const {data:{user},error:authError}=await db.auth.getUser();
   if(authError||!user){setMessage("Материал қосу үшін алдымен жүйеге кіріңіз.");setBusy(false);return;}
   const form=e.currentTarget;const fd=new FormData(form);const file=fd.get("file") as File;
   if(!file||!file.size){setMessage("Файлды таңдаңыз.");setBusy(false);return;}
   const ext=file.name.split(".").pop()?.toLowerCase()||"";
   if(!ALLOWED.has(ext)){setMessage("Бұл файл форматына рұқсат жоқ.");setBusy(false);return;}
   if(file.size>MAX_SIZE){setMessage("Файл көлемі 25 МБ-тан аспауы керек.");setBusy(false);return;}
   const title=String(fd.get("title")||"").trim();if(!title){setMessage("Материал атауын енгізіңіз.");setBusy(false);return;}
   const visibility=String(fd.get("visibility")||"private");
   const filePath=`${user.id}/${crypto.randomUUID()}.${ext}`;
   setProgress(20);
   const {error:uploadError}=await db.storage.from("materials").upload(filePath,file,{contentType:file.type||"application/octet-stream",upsert:false});
   if(uploadError)throw uploadError;setProgress(75);
   const row={owner_id:user.id,title,description:String(fd.get("description")||""),type:String(fd.get("type")||"other"),subject:String(fd.get("subject")||""),grade:Number(fd.get("grade")||0)||null,topic:String(fd.get("topic")||""),learning_objective:String(fd.get("learning_objective")||""),keywords:String(fd.get("keywords")||"").split(",").map(s=>s.trim()).filter(Boolean),visibility,status:visibility==="public"?"pending":"draft",file_path:filePath,file_name:file.name,mime_type:file.type,file_size:file.size};
   const {error:dbError}=await db.from("materials").insert(row);if(dbError){await db.storage.from("materials").remove([filePath]);throw dbError;}
   setProgress(100);setMessage(visibility==="public"?"Материал модерацияға жіберілді.":"Материал жеке нобай ретінде сақталды.");form.reset();
  }catch(err){setMessage(err instanceof Error?err.message:"Жүктеу кезінде қате орын алды.");}
  finally{setBusy(false);}
 }
 return <main className="container"><h1 className="page-title">Материал қосу</h1><p className="muted">Өз материалыңызды қауіпсіз жүктеп, жеке сақтаңыз немесе модерацияға жіберіңіз.</p><form className="panel" onSubmit={submit} style={{marginTop:22,marginBottom:30}}><div className="notice" style={{marginBottom:20}}>Жария материалдар модерациядан кейін ғана кітапханада көрінеді. Файл көлемі — 25 МБ-қа дейін. Қолдау көрсетілетін форматтар: PDF, Office, JPG/PNG, ZIP және HTML.</div><div className="form-grid">
 <label className="field">Материалдың атауы *<input name="title" required maxLength={180} placeholder="Мысалы: 2-сынып математика ҚМЖ"/></label>
 <label className="field">Материал түрі *<select name="type" required>{MATERIAL_TYPES.map(t=><option value={t.value} key={t.value}>{t.label}</option>)}</select></label>
 <label className="field">Пәні<select name="subject"><option value="">Таңдаңыз</option>{SUBJECTS.map(s=><option key={s}>{s}</option>)}</select></label>
 <label className="field">Сыныбы<select name="grade" defaultValue=""><option value="">Таңдаңыз</option>{[1,2,3,4].map(n=><option key={n} value={n}>{n}-сынып</option>)}</select></label>
 <label className="field">Тақырыбы<input name="topic" maxLength={180} placeholder="Сабақ немесе бөлім тақырыбы"/></label>
 <label className="field">Оқу мақсаты<input name="learning_objective" maxLength={500} placeholder="Оқу мақсатын жазыңыз"/></label>
 <label className="field" style={{gridColumn:"1/-1"}}>Қысқаша сипаттамасы<textarea name="description" maxLength={3000} placeholder="Материалдың мазмұны мен қолдану мақсаты"/></label>
 <label className="field" style={{gridColumn:"1/-1"}}>Кілт сөздер<input name="keywords" placeholder="көбейту, 2-сынып, математика (үтірмен бөліңіз)"/></label>
 <label className="field" style={{gridColumn:"1/-1"}}>Файл *<input name="file" type="file" required accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.jpg,.jpeg,.png,.zip,.html"/></label>
 <label className="field" style={{gridColumn:"1/-1"}}>Көрінуі<select name="visibility"><option value="private">Жеке сақтау</option><option value="public">Жариялау үшін жіберу</option></select></label>
 </div>{busy&&<div style={{height:7,background:"#e6edf5",borderRadius:8,marginTop:18,overflow:"hidden"}}><div style={{height:"100%",width:`${progress}%`,background:"#173b67",transition:"width .2s"}}/></div>}{message&&<p className="notice" role="status" style={{marginTop:16}}>{message}</p>}<div style={{display:"flex",gap:10,marginTop:20,flexWrap:"wrap"}}><button disabled={busy} className="btn btn-primary" type="submit">{busy?"Жүктелуде…":"Сақтау"}</button><Link className="btn btn-secondary" href="/materials">Каталогқа оралу</Link></div></form></main>
}