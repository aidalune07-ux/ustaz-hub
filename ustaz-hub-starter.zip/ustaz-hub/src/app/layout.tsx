import type { Metadata } from "next";
import "./globals.css";
import Link from "next/link";
import { BookOpen, Search, Upload, UserRound } from "lucide-react";
export const metadata: Metadata = { title: "ҰСТАЗ HUB — білім кеңістігі", description: "Бастауыш сынып мұғалімдеріне арналған ортақ білім кеңістігі." };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
 return <html lang="kk"><body>
  <header className="header"><div className="container" style={{height:72,display:"flex",alignItems:"center",justifyContent:"space-between",gap:18}}>
   <Link href="/" className="logo"><span className="logo-mark"><BookOpen size={20}/></span><span>ҰСТАЗ HUB</span></Link>
   <nav className="desktop-nav" style={{display:"flex",alignItems:"center",gap:8}}>
    <Link className="nav-link" href="/materials">Материалдар</Link><Link className="nav-link" href="/materials?type=qmg">ҚМЖ</Link><Link className="nav-link" href="/games">Ойындар</Link><Link className="nav-link" href="/ai">ЖИ құралдары</Link>
   </nav>
   <div style={{display:"flex",gap:8}}><Link className="btn btn-secondary" href="/materials"><Search size={16}/> <span className="desktop-nav">Іздеу</span></Link><Link className="btn btn-primary" href="/upload"><Upload size={16}/> Қосу</Link><Link className="btn btn-secondary" href="/account" aria-label="Жеке кабинет"><UserRound size={17}/></Link></div>
  </div></header>
  {children}
  <footer className="footer"><div className="container" style={{display:"flex",justifyContent:"space-between",gap:16,flexWrap:"wrap"}}><span>© {new Date().getFullYear()} ҰСТАЗ HUB. Мұғалімдерге арналған ортақ білім кеңістігі.</span><span>Материал авторының құқықтарын құрметтеңіз. Жүктеген файлды таратуға рұқсатыңыз болуы керек.</span></div></footer>
 </body></html>;
}