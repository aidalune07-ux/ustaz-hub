export const MATERIAL_TYPES = [
  { value: "qmg", label: "ҚМЖ" }, { value: "game", label: "Ойындар" },
  { value: "presentation", label: "Презентациялар" }, { value: "bjb", label: "БЖБ" },
  { value: "tjb", label: "ТЖБ" }, { value: "test", label: "Тесттер" },
  { value: "other", label: "Басқа материал" }
] as const;
export const SUBJECTS = ["Қазақ тілі","Әдебиеттік оқу","Математика","Дүниетану","Жаратылыстану","Ағылшын тілі","Көркем еңбек","Музыка","Сауат ашу","Дене шынықтыру","Басқа пән"] as const;
export type MaterialType = typeof MATERIAL_TYPES[number]["value"];
export type Material = {
  id: string; title: string; description: string | null; type: MaterialType;
  subject: string | null; grade: number | null; topic: string | null;
  author_name?: string; created_at: string; downloads: number; views: number;
  cover_url: string | null; file_path: string | null; file_name: string | null;
};