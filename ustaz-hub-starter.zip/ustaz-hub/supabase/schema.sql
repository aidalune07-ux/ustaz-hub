-- ҰСТАЗ HUB initial schema. Run in Supabase SQL Editor.
create extension if not exists pgcrypto;

create type public.app_role as enum ('teacher','admin');
create type public.material_status as enum ('draft','pending','published','rejected');
create type public.material_visibility as enum ('private','public');
create type public.material_type as enum ('qmg','game','presentation','bjb','tjb','test','other');

create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text not null default '',
 school text,
 teaching_grade smallint check (teaching_grade between 1 and 4),
 avatar_url text,
 role public.app_role not null default 'teacher',
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create table public.materials (
 id uuid primary key default gen_random_uuid(),
 owner_id uuid not null references auth.users(id) on delete cascade,
 title text not null check (char_length(title) between 1 and 180),
 description text not null default '',
 type public.material_type not null default 'other',
 subject text not null default '',
 grade smallint check (grade between 1 and 4),
 topic text not null default '',
 learning_objective text not null default '',
 keywords text[] not null default '{}',
 cover_url text,
 file_path text,
 file_name text,
 mime_type text,
 file_size bigint check (file_size is null or file_size <= 26214400),
 visibility public.material_visibility not null default 'private',
 status public.material_status not null default 'draft',
 downloads bigint not null default 0,
 views bigint not null default 0,
 author_name text,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create index materials_public_created_idx on public.materials(status,visibility,created_at desc);
create index materials_type_grade_idx on public.materials(type,grade,subject);
create index materials_keywords_idx on public.materials using gin(keywords);

create table public.favorites (
 user_id uuid not null references auth.users(id) on delete cascade,
 material_id uuid not null references public.materials(id) on delete cascade,
 created_at timestamptz not null default now(),
 primary key(user_id,material_id)
);
create table public.comments (
 id uuid primary key default gen_random_uuid(),
 material_id uuid not null references public.materials(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 body text not null check (char_length(body) between 1 and 2000),
 created_at timestamptz not null default now()
);
create table public.material_ratings (
 material_id uuid not null references public.materials(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 rating smallint not null check (rating between 1 and 5),
 created_at timestamptz not null default now(),
 primary key(material_id,user_id)
);
create table public.reports (
 id uuid primary key default gen_random_uuid(),
 material_id uuid not null references public.materials(id) on delete cascade,
 reporter_id uuid references auth.users(id) on delete set null,
 reason text not null check (char_length(reason) between 3 and 1000),
 status text not null default 'open' check(status in ('open','reviewing','resolved','dismissed')),
 created_at timestamptz not null default now()
);
create table public.test_results (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 test_material_id uuid references public.materials(id) on delete set null,
 score numeric not null default 0,
 max_score numeric not null default 0,
 answers jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin'); $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$ begin
 insert into public.profiles(id,full_name) values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''));
 return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.materials enable row level security;
alter table public.favorites enable row level security;
alter table public.comments enable row level security;
alter table public.material_ratings enable row level security;
alter table public.reports enable row level security;
alter table public.test_results enable row level security;

create policy "profiles visible to owner or admin" on public.profiles for select to authenticated using(id=auth.uid() or public.is_admin());
create policy "profile owner update safe fields" on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid() and role='teacher');
create policy "published public materials visible" on public.materials for select using((visibility='public' and status='published') or owner_id=auth.uid() or public.is_admin());
create policy "teacher creates own material" on public.materials for insert to authenticated with check(owner_id=auth.uid() and status in ('draft','pending'));
create policy "owner updates own material" on public.materials for update to authenticated using(owner_id=auth.uid() or public.is_admin()) with check((owner_id=auth.uid() and status in ('draft','pending')) or public.is_admin());
create policy "owner or admin deletes material" on public.materials for delete to authenticated using(owner_id=auth.uid() or public.is_admin());
create policy "favorites own rows" on public.favorites for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy "comments on published material visible" on public.comments for select using(exists(select 1 from public.materials m where m.id=material_id and m.status='published' and m.visibility='public') or user_id=auth.uid() or public.is_admin());
create policy "authenticated user adds own comment" on public.comments for insert to authenticated with check(user_id=auth.uid() and char_length(body) between 1 and 2000);
create policy "comment owner deletes" on public.comments for delete to authenticated using(user_id=auth.uid() or public.is_admin());
create policy "ratings readable" on public.material_ratings for select using(true);
create policy "user manages own rating" on public.material_ratings for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy "user creates report" on public.reports for insert to authenticated with check(reporter_id=auth.uid());
create policy "reporter and admin read reports" on public.reports for select to authenticated using(reporter_id=auth.uid() or public.is_admin());
create policy "admin manages reports" on public.reports for update to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "test results private" on public.test_results for select to authenticated using(user_id=auth.uid() or public.is_admin());
create policy "user inserts own result" on public.test_results for insert to authenticated with check(user_id=auth.uid());

-- Private storage bucket. Keep files private; use short-lived signed URLs.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('materials','materials',false,26214400,array[
 'application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document',
 'application/vnd.ms-powerpoint','application/vnd.openxmlformats-officedocument.presentationml.presentation',
 'application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
 'image/jpeg','image/png','application/zip','text/html','application/octet-stream'
]) on conflict(id) do nothing;
create policy "user can upload to own folder" on storage.objects for insert to authenticated
with check(bucket_id='materials' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "owner or admin can read own files" on storage.objects for select to authenticated
using(bucket_id='materials' and ((storage.foldername(name))[1]=auth.uid()::text or public.is_admin()));
create policy "owner can delete own files" on storage.objects for delete to authenticated
using(bucket_id='materials' and (storage.foldername(name))[1]=auth.uid()::text);

-- After creating your own account, assign admin in SQL Editor:
-- update public.profiles set role='admin' where id='YOUR_AUTH_USER_UUID';
